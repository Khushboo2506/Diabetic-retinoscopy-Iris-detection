from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from .models import User
from django.db.models import Q
from django.contrib import messages

# Create your views here.
def dashboard(request):
    return render(request, "dashboard.html")

def user(request):
    if request.method == 'POST':
        armyno = request.POST['armyno']
        firstname = request.POST['firstname']
        lastname = request.POST['lastname']
        posttype = request.POST['posttype']
        relation = request.POST['relation']
        sex = request.POST['sex']
        age = request.POST['age']
        rank = request.POST['rank']
        healthproblem = request.POST['healthproblem']
        problemhistory = request.POST['problemhistory']
        
        patient = User(armyno=armyno,firstname=firstname,lastname=lastname,posttype=posttype,relation=relation,sex=sex,age=age,rank=rank,healthproblem=healthproblem,problemhistory=problemhistory)
        patient.save()
        print("Done")
        return redirect('/dashboard/analyze')
    else:
        count= User.objects.all().count()
        context= {'count': count}
        return render(request, "user.html", context)

def analyze(request):
    patientinfo = User.objects.all()
    print(patientinfo)
    return render(request, "analyze.html", {'info': patientinfo })

def visualize(request):
    return render(request, "visualize.html")

def search(request):
    if request.method == 'POST':
        search = request.POST['search']
        
        if search:
            match = User.objects.filter(Q(id__icontains=search) |
                                        Q(armyno__icontains=search)
                                        
                                        )
            if match:
                return render(request,'search.html',{'sr':match})
            else:
                messages.error(request,'No result found!')
        else:
            return redirect('/dashboard/search')
 
    return render(request, "search.html")

def logout(request):
    auth.logout(request)
    return redirect('/')
